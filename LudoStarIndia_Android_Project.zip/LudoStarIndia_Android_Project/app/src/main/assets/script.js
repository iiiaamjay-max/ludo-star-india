const C=['R','G','Y','B'],N=['Red','Green','Yellow','Blue'];
// Standard 52-space outer track coordinates on a 15x15 grid.
const track=[[6,0],[6,1],[6,2],[6,3],[6,4],[5,4],[4,4],[3,4],[2,4],[1,4],[0,4],[0,5],[0,6],[1,6],[2,6],[3,6],[4,6],[4,7],[4,8],[3,8],[2,8],[1,8],[0,8],[0,9],[0,10],[1,10],[2,10],[3,10],[4,10],[5,10],[6,10],[6,11],[6,12],[6,13],[6,14],[7,14],[8,14],[8,13],[8,12],[8,11],[8,10],[9,10],[10,10],[11,10],[12,10],[13,10],[14,10],[14,9],[14,8],[13,8],[12,8],[11,8],[10,8],[10,7],[10,6],[11,6],[12,6],[13,6],[14,6],[14,5],[14,4],[13,4],[12,4],[11,4],[10,4],[10,3],[10,2],[10,1],[10,0],[9,0],[8,0],[8,1],[8,2],[8,3],[8,4],[7,4],[6,4]];
// Use first 52 unique cells as playable route.
const route=track.slice(0,52);
const start=[0,13,26,39], players=4; let activePlayers=2,ai=true,turn=0,dice=0,tokens=[];

function show(id){document.querySelectorAll('.screen').forEach(x=>x.classList.remove('active'));document.getElementById(id).classList.add('active')}
function goHome(){show('home')}
function newGame(n,bot){activePlayers=n;ai=bot;turn=0;dice=0;tokens=Array.from({length:n},()=>[-1,-1,-1,-1]);show('game');draw();msg(N[turn]+"'s turn — roll the dice.")}
function yardColor(r,c){if(r<=5&&c<=5)return 'yardR';if(r<=5&&c>=9)return 'yardG';if(r>=9&&c<=5)return 'yardB';if(r>=9&&c>=9)return 'yardY';return ''}
function draw(){
 const b=document.getElementById('board');b.innerHTML='';
 for(let r=0;r<15;r++)for(let c=0;c<15;c++){
  const d=document.createElement('div');d.className='cell '+yardColor(r,c);
  const idx=route.findIndex(x=>x[0]===r&&x[1]===c);
  if(idx>=0){d.className='cell path';if([0,8,13,21,26,34,39,47].includes(idx))d.classList.add('safe')}
  if(r>=6&&r<=8&&c>=6&&c<=8)d.className='cell home';
  if(idx>=0){
   for(let p=0;p<activePlayers;p++)for(let k=0;k<4;k++)if(tokens[p][k]>=0&&tokens[p][k]<52){
    let pos=(start[p]+tokens[p][k])%52;if(pos===idx){let e=document.createElement('div');e.className='piece '+C[p];e.title=N[p]+' token';e.onclick=()=>move(p,k);d.appendChild(e)}
   }
  }
  b.appendChild(d)
 }
 document.getElementById('turn').textContent=N[turn]+"'s turn";document.getElementById('dice').textContent=dice?'🎲 '+dice:'🎲';
 document.getElementById('roll').disabled=!!dice||tokens[turn].every(v=>v===52);
 document.getElementById('tokenInfo').innerHTML=tokens[turn].map((v,k)=>'<div class="info">Token '+(k+1)+': '+(v<0?'Home':v===52?'Finished':'Step '+v)+'</div>').join('');
}
function rollDice(){if(dice)return;dice=1+Math.floor(Math.random()*6);draw();
 let ok=tokens[turn].some((v)=>v<52&&(v===-1?dice===6:v+dice<=52));
 if(!ok){msg(N[turn]+' rolled '+dice+'. No valid move.');setTimeout(next,700);return}
 msg(N[turn]+' rolled '+dice+' — tap a token.');
 if(ai&&turn===1)setTimeout(()=>{let k=tokens[1].findIndex(v=>v<52&&(v===-1?dice===6:v+dice<=52));if(k>=0)move(1,k)},650)}
function move(p,k){if(p!==turn||!dice)return;let v=tokens[p][k];if(v>=52)return;if(v===-1){if(dice!==6)return;v=0}else{if(v+dice>52)return;v+=dice}tokens[p][k]=v;
 // Capture opponents on non-safe squares.
 if(v<52){let pos=(start[p]+v)%52;let safe=[0,8,13,21,26,34,39,47].includes(pos);if(!safe)for(let q=0;q<activePlayers;q++)if(q!==p)for(let j=0;j<4;j++)if(tokens[q][j]>=0&&tokens[q][j]<52&&(start[q]+tokens[q][j])%52===pos)tokens[q][j]=-1}
 if(tokens[p].every(x=>x===52)){msg(N[p]+' WINS! 🏆');dice=0;draw();return}
 if(dice===6){dice=0;draw();msg(N[p]+' rolled 6 — roll again!');return}next()}
function next(){dice=0;turn=(turn+1)%activePlayers;draw();msg(N[turn]+"'s turn — roll the dice.");}
function msg(t){document.getElementById('msg').textContent=t}

window.addEventListener('load',()=>setTimeout(()=>document.getElementById('splash')?.remove(),2600));
