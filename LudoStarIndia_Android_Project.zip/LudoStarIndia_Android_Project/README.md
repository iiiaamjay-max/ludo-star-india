# Ludo Star India
Original Ludo web game packaged as an Android WebView app. GitHub Actions builds a debug APK.
